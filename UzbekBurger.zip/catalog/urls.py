
urlpatterns = [
]
