from django.apps import AppConfig


class FinanceConfig(AppConfig):
    name = 'sales'
    verbose_name = "Sotuv"
