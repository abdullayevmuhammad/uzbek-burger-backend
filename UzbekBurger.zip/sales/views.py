from __future__ import annotations

import json
from typing import Any

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.http import HttpResponseForbidden, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods, require_POST

from core.middleware import get_active_branch
from core.services import ensure_branch_is_operational
from finance.models import MoneyAccount
from finance.utils import parse_uzs_amount
from menu.models import Food, FoodType
from users.utils import is_admin_user

from .models import Order
from .services import (
    OrderValidationError,
    build_receipt_context,
    cancel_order,
    create_order_with_items,
    ensure_kitchen_task,
    mark_delivered,
    pay_order,
)


def _is_admin_like(user) -> bool:
    return is_admin_user(user)


def _require_branch(request):
    """POS ishlashi uchun faol filial kerak."""
    branch = get_active_branch(request)
    if branch:
        return ensure_branch_is_operational(branch)
    if _is_admin_like(request.user):
        raise LookupError("branch_not_selected")
    raise PermissionError("Faol filial tanlanmagan")


def _branch_accounts(branch, *, ensure_default: bool = False):
    """Filial kassalari (MoneyAccount)."""
    qs = MoneyAccount.objects.filter(branch=branch, is_active=True).order_by("name")
    if ensure_default and not qs.exists():
        from finance.models import AccountKind

        MoneyAccount.objects.get_or_create(
            branch=branch,
            name="Kassa",
            defaults={"kind": AccountKind.CASH, "is_active": True},
        )
        qs = MoneyAccount.objects.filter(branch=branch, is_active=True).order_by("name")
    return qs


@login_required
def pos_orders(request):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    status = (request.GET.get("status") or "").strip()
    delivered = (request.GET.get("delivered") or "").strip()

    qs = (
        Order.objects.filter(branch=branch)
        .select_related("created_by", "paid_by", "delivered_by")
        .order_by("-created_at")
    )

    if status in {Order.Status.DRAFT, Order.Status.PAID, Order.Status.CANCELED}:
        qs = qs.filter(status=status)

    if delivered in {"0", "1"}:
        qs = qs.filter(is_delivered=(delivered == "1"))

    orders = list(qs[:200])

    return render(
        request,
        "sales/pos_orders.html",
        {
            "branch": branch,
            "orders": orders,
            "status": status,
            "delivered": delivered,
            "Status": Order.Status,
        },
    )


@login_required
@require_http_methods(["GET", "POST"])
def pos_order_create(request):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    foods_qs = (
        Food.objects.filter(is_active=True, branch=branch)
        .select_related("category")
        .order_by("type", "category__sort_order", "sort_order", "name")
    )

    foods_json: list[dict[str, Any]] = []
    for f in foods_qs:
        img = None
        try:
            if f.image:
                img = f.image.url
        except Exception:
            img = None

        foods_json.append(
            {
                "id": str(f.id),
                "name": f.name,
                "type": f.type,
                "sell_price": int(f.sell_price),
                "image": img,
            }
        )

    accounts = list(_branch_accounts(branch))
    single_account = accounts[0] if len(accounts) == 1 else None

    if request.method == "POST":
        raw_items = request.POST.get("items_json") or "[]"
        try:
            items = json.loads(raw_items)
        except Exception:
            messages.error(request, "Chek ma'lumotlari xato (items_json).")
            return redirect("sales:pos_order_create")

        order_type = request.POST.get("order_type") or Order.OrderType.DINE_IN
        if order_type not in {c for c, _ in Order.OrderType.choices}:
            order_type = Order.OrderType.DINE_IN

        is_paid = (request.POST.get("is_paid") or "") == "1"
        is_delivered = (request.POST.get("is_delivered") or "") == "1"
        account_id = (request.POST.get("account_id") or "").strip()
        paid_amount_raw = (request.POST.get("paid_amount") or "").strip()
        note = (request.POST.get("note") or "").strip() or None

        try:
            with transaction.atomic():
                order = create_order_with_items(
                    branch=branch,
                    created_by=request.user,
                    order_type=order_type,
                    note=note,
                    items=items,
                )

                order.refresh_from_db()

                if is_delivered:
                    mark_delivered(order, by_user=request.user)

                if is_paid:
                    if not account_id:
                        acc = single_account
                    else:
                        acc = get_object_or_404(MoneyAccount, id=account_id, branch=branch, is_active=True)

                    if acc is None:
                        raise ValueError("Faol to'lov hisobi topilmadi. Admin: filial uchun kamida bitta hisob yarating.")

                    if paid_amount_raw:
                        amount = parse_uzs_amount(paid_amount_raw)
                    else:
                        amount = int(order.total_amount)

                    if amount > 0:
                        pay_order(order, account=acc, amount=amount, by_user=request.user)

                return redirect("sales:pos_order_detail", pk=order.pk)

        except OrderValidationError as e:
            messages.error(request, str(e))
            return redirect("sales:pos_order_create")
        except Exception as e:
            messages.error(request, f"Order yaratilmadi: {e}")
            return redirect("sales:pos_order_create")

    return render(
        request,
        "sales/pos_order_create.html",
        {
            "branch": branch,
            "foods": list(foods_qs),
            "foods_json": json.dumps(foods_json, ensure_ascii=False),
            "FoodType": FoodType,
            "accounts": accounts,
            "single_account": single_account,
            "has_payment_accounts": bool(accounts),
            "OrderType": Order.OrderType,
            "hide_sidebar": True,
            "hide_topbar": True,
            "body_class": "no-sidebar pos-no-nav",
        },
    )


@login_required
def pos_order_detail(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(
        Order.objects.select_related("created_by", "paid_by", "delivered_by"),
        pk=pk,
        branch=branch,
    )
    items = list(order.items.select_related("food").all().order_by("food__name"))
    payments = list(order.payments.select_related("account").all().order_by("-created_at"))

    accounts = list(_branch_accounts(branch))
    single_account = accounts[0] if len(accounts) == 1 else None
    due = max(0, int(order.total_amount) - int(order.paid_amount))

    return render(
        request,
        "sales/pos_order_detail.html",
        {
            "branch": branch,
            "order": order,
            "items": items,
            "payments": payments,
            "accounts": accounts,
            "single_account": single_account,
            "has_payment_accounts": bool(accounts),
            "due": due,
            "Status": Order.Status,
            "OrderType": Order.OrderType,
        },
    )


@login_required
@require_POST
def pos_order_pay(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(Order, pk=pk, branch=branch)

    if order.is_locked:
        messages.error(request, "Bu buyurtma yakunlangan. Endi o'zgartirib bo'lmaydi.")
        return redirect("sales:pos_order_detail", pk=pk)

    account_id = (request.POST.get("account_id") or "").strip()
    amount_raw = (request.POST.get("amount") or "").strip()
    note = (request.POST.get("note") or "").strip() or None

    accounts = list(_branch_accounts(branch))
    single_account = accounts[0] if len(accounts) == 1 else None

    if not account_id:
        if single_account is not None:
            acc = single_account
        else:
            message = "Faol to'lov hisobi topilmadi. Admin: filial uchun kamida bitta hisob yarating."
            if accounts:
                message = "Kassa tanlang."
            messages.error(request, message)
            return redirect("sales:pos_order_detail", pk=pk)
    else:
        acc = get_object_or_404(MoneyAccount, id=account_id, branch=branch, is_active=True)

    try:
        amount = parse_uzs_amount(amount_raw)
    except Exception:
        messages.error(request, "To'lov summasi noto'g'ri.")
        return redirect("sales:pos_order_detail", pk=pk)

    try:
        pay_order(order, account=acc, amount=amount, note=note, by_user=request.user)
        messages.success(request, "To'lov qabul qilindi.")
    except Exception as e:
        messages.error(request, f"To'lovda xatolik: {e}")

    return redirect("sales:pos_order_detail", pk=pk)


@login_required
@require_POST
def pos_order_deliver(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(Order, pk=pk, branch=branch)

    if order.is_locked:
        messages.error(request, "Bu buyurtma yakunlangan. Endi o'zgartirib bo'lmaydi.")
        return redirect("sales:pos_order_detail", pk=pk)

    try:
        mark_delivered(order, by_user=request.user)
        messages.success(request, "Order 'topshirildi' deb belgilandi (stock yechildi).")
    except Exception as e:
        messages.error(request, f"Topshirishda xatolik: {e}")

    return redirect("sales:pos_order_detail", pk=pk)


@login_required
@require_POST
def pos_order_cancel(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(Order, pk=pk, branch=branch)

    try:
        cancel_order(order, by_user=request.user)
        messages.success(request, "Buyurtma bekor qilindi.")
    except Exception as e:
        messages.error(request, f"Bekor qilishda xatolik: {e}")

    return redirect("sales:pos_order_detail", pk=pk)


@login_required
def pos_menu_json(request):
    try:
        branch = _require_branch(request)
    except LookupError:
        return JsonResponse({"error": "branch_not_selected"}, status=400)
    except PermissionError:
        return JsonResponse({"error": "no_branch"}, status=403)

    foods_qs = Food.objects.filter(is_active=True, branch=branch).order_by("type", "sort_order", "name")

    out = []
    for f in foods_qs:
        out.append(
            {
                "id": str(f.id),
                "name": f.name,
                "type": f.type,
                "sell_price": int(f.sell_price),
            }
        )
    return JsonResponse({"branch": str(branch.id), "foods": out})


@login_required
def pos_order_receipt(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(Order, pk=pk, branch=branch)
    # paper_width = request.GET.get("paper", "80")
    ctx = build_receipt_context(order)
    ctx.update({"branch": branch})
    return render(request, "sales/receipt.html", ctx)


@login_required
def pos_order_kitchen_task(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(Order.objects.select_related("branch"), pk=pk, branch=branch)
    task = ensure_kitchen_task(order, actor=request.user)

    if request.method == "POST":
        new_status = request.POST.get("status")
        if new_status in {c for c, _ in task.Status.choices}:
            task.status = new_status
            task.updated_by = request.user
            task.save(update_fields=["status", "updated_by", "updated_at"])
        return redirect("sales:pos_order_kitchen", pk=pk)

    return render(
        request,
        "sales/kitchen_task.html",
        {
            "branch": branch,
            "order": order,
            "task": task,
            "items": order.items.select_related("food"),
            "hide_sidebar": True,
            "hide_topbar": True,
            "body_class": "no-sidebar pos-no-nav",
        },
    )

from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect
from django.http import HttpResponseForbidden

from sales.models import Order
from sales.services import build_receipt_context

@login_required
def pos_order_receipt_data(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(Order, pk=pk, branch=branch)
    ctx = build_receipt_context(order)

    return JsonResponse({
        "ok": True,
        "doc_type": "receipt",
        "branch": {
            "name": ctx["branch"].name,
            "address": getattr(ctx["branch"], "public_address", "") or "",
            "phone": getattr(ctx["branch"], "public_phone", "") or "",
        },
        "order": {
            "id": str(ctx["order"].id)[:8],
            "created_at": ctx["order"].created_at.strftime("%d.%m.%Y %H:%M"),
            "cashier": ctx["order"].created_by.username if ctx["order"].created_by else "-",
            "type": ctx["order"].get_order_type_display(),
            "total_amount": ctx["total_amount"],
            "paid_amount": ctx["paid_amount"],
            "due": ctx["due"],
            "is_delivered": bool(ctx["order"].is_delivered),
            "is_fully_paid": bool(ctx["order"].is_fully_paid),
        },
        "items": ctx["items"],
        "payments": [
            {
                "amount": p["amount"],
                "account": p["account"],
                "created_at": p["created_at"].strftime("%d.%m %H:%M"),
            }
            for p in ctx["payments"]
        ],
    })

@login_required
def pos_order_kitchen_print_data(request, pk):
    try:
        branch = _require_branch(request)
    except LookupError:
        return redirect("select_branch")
    except PermissionError:
        return HttpResponseForbidden("Sizga filial biriktirilmagan yoki faol filial tanlanmagan.")

    order = get_object_or_404(Order.objects.select_related("branch"), pk=pk, branch=branch)
    task = ensure_kitchen_task(order, actor=request.user)

    return JsonResponse({
        "ok": True,
        "doc_type": "kitchen",
        "branch": {
            "name": branch.name,
        },
        "order": {
            "id": str(order.id)[:8],
            "created_at": order.created_at.strftime("%d.%m.%Y %H:%M"),
            "type": order.get_order_type_display(),
        },
        "items": [
            {
                "name": it.food.name,
                "qty": it.qty,
            }
            for it in order.items.select_related("food").all()
        ],
        "note": task.note or order.note or "",
    })